﻿using System.Drawing;
using System.Windows.Forms;

namespace Colorimetria
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        // === Sidebar ===
        private Panel sidebar;
        private Label lblTitulo;
        private Button btnNuevoAnalisis;
        private Button btnHistorial;
        private Button btnTolerancias;
        private Button btnBaseDatos;

        // === Área principal y Card ===
        private Panel mainArea;
        private Panel cardPanel;
        private PictureBox picLogo;
        private Label lblCardTitulo;
        private Label lblCardSubtitulo;

        // === Visor y UI dinámica ===
        private PictureBox picViewer;   // visor de imágenes
        private Label lblDropHint;      // placeholder dentro del visor
        private Label lblInfo;          // metadatos
        private Button btnAccion;       // botón grande (cargar)
        private Button btnScan;         // iniciar escaneo
        private Button btnCancelar;     // cancelar (volver a inicio)

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.sidebar = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnNuevoAnalisis = new System.Windows.Forms.Button();
            this.btnHistorial = new System.Windows.Forms.Button();
            this.btnTolerancias = new System.Windows.Forms.Button();
            this.btnBaseDatos = new System.Windows.Forms.Button();

            this.mainArea = new System.Windows.Forms.Panel();

            this.cardPanel = new System.Windows.Forms.Panel();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.lblCardTitulo = new System.Windows.Forms.Label();
            this.lblCardSubtitulo = new System.Windows.Forms.Label();
            this.picViewer = new System.Windows.Forms.PictureBox();
            this.lblDropHint = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnAccion = new System.Windows.Forms.Button();
            this.btnScan = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picViewer)).BeginInit();
            this.SuspendLayout();

            // ===== FORM =====
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 620);
            this.MinimumSize = new System.Drawing.Size(920, 560);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "COLORIMETRIA";

            // ===== SIDEBAR =====
            this.sidebar.BackColor = System.Drawing.Color.FromArgb(18, 39, 71);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(250, 620);
            this.sidebar.TabIndex = 0;

            // Título sidebar
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(20, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(176, 25);
            this.lblTitulo.TabIndex = 1;
            this.lblTitulo.Text = "COATS CADENA";
            this.sidebar.Controls.Add(this.lblTitulo);

            // Botones sidebar
            this.btnNuevoAnalisis.Text = "Nuevo análisis";
            this.btnNuevoAnalisis.Location = new System.Drawing.Point(20, 80);
            this.btnNuevoAnalisis.Size = new System.Drawing.Size(200, 35);
            this.btnNuevoAnalisis.BackColor = Color.FromArgb(28, 62, 118);
            this.btnNuevoAnalisis.FlatStyle = FlatStyle.Flat;
            this.btnNuevoAnalisis.ForeColor = Color.White;
            this.sidebar.Controls.Add(this.btnNuevoAnalisis);

            this.btnHistorial.Text = "Historial de lotes";
            this.btnHistorial.Location = new System.Drawing.Point(20, 125);
            this.btnHistorial.Size = new System.Drawing.Size(200, 35);
            this.btnHistorial.BackColor = Color.FromArgb(28, 62, 118);
            this.btnHistorial.FlatStyle = FlatStyle.Flat;
            this.btnHistorial.ForeColor = Color.White;
            this.sidebar.Controls.Add(this.btnHistorial);

            this.btnTolerancias.Text = "Config. de tolerancias";
            this.btnTolerancias.Location = new System.Drawing.Point(20, 170);
            this.btnTolerancias.Size = new System.Drawing.Size(200, 35);
            this.btnTolerancias.BackColor = Color.FromArgb(24, 105, 54);
            this.btnTolerancias.FlatStyle = FlatStyle.Flat;
            this.btnTolerancias.ForeColor = Color.White;
            this.sidebar.Controls.Add(this.btnTolerancias);

            this.btnBaseDatos.Text = "Base de datos";
            this.btnBaseDatos.Location = new System.Drawing.Point(20, 215);
            this.btnBaseDatos.Size = new System.Drawing.Size(200, 35);
            this.btnBaseDatos.BackColor = Color.FromArgb(24, 105, 54);
            this.btnBaseDatos.FlatStyle = FlatStyle.Flat;
            this.btnBaseDatos.ForeColor = Color.White;
            this.sidebar.Controls.Add(this.btnBaseDatos);

            // ===== MAIN AREA =====
            this.mainArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainArea.BackColor = System.Drawing.Color.FromArgb(242, 246, 252);
            this.mainArea.Name = "mainArea";

            // ===== CARD =====
            this.cardPanel.Size = new System.Drawing.Size(560, 460);
            this.cardPanel.BackColor = System.Drawing.Color.White;
            this.cardPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardPanel.Location = new System.Drawing.Point(95, 80);
            this.cardPanel.Name = "cardPanel";

            // Logo (placeholder)
            this.picLogo.Size = new System.Drawing.Size(120, 120);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.BackColor = System.Drawing.Color.White;
            this.picLogo.Location = new System.Drawing.Point(220, 20);
            this.picLogo.Name = "picLogo";
            // this.picLogo.Image = Properties.Resources.TuLogo;

            // Título
            this.lblCardTitulo.AutoSize = true;
            this.lblCardTitulo.Text = "COATS CADENA";
            this.lblCardTitulo.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblCardTitulo.ForeColor = System.Drawing.Color.FromArgb(23, 43, 77);
            this.lblCardTitulo.Location = new System.Drawing.Point(200, 150);
            this.lblCardTitulo.Name = "lblCardTitulo";

            // Subtítulo
            this.lblCardSubtitulo.AutoSize = true;
            this.lblCardSubtitulo.Text = "Analiza colores a partir de escaneo o imagen";
            this.lblCardSubtitulo.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblCardSubtitulo.ForeColor = System.Drawing.Color.FromArgb(90, 110, 140);
            this.lblCardSubtitulo.Location = new System.Drawing.Point(120, 180);
            this.lblCardSubtitulo.Name = "lblCardSubtitulo";

            // Visor
            this.picViewer.Name = "picViewer";
            this.picViewer.BackColor = System.Drawing.Color.White;
            this.picViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picViewer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picViewer.Location = new System.Drawing.Point(30, 210);
            this.picViewer.Size = new System.Drawing.Size(500, 200);

            // Placeholder (hint) dentro del visor
            this.lblDropHint.Name = "lblDropHint";
            this.lblDropHint.AutoSize = false;
            this.lblDropHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDropHint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDropHint.ForeColor = System.Drawing.Color.FromArgb(120, 120, 120);
            this.lblDropHint.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular);
            this.lblDropHint.Text = "Haz clic para cargar\no arrastra una imagen";
            this.lblDropHint.BackColor = System.Drawing.Color.Transparent;
            this.picViewer.Controls.Add(this.lblDropHint);

            // Metadatos
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.AutoSize = false;
            this.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfo.Text = "Sin imagen cargada";
            this.lblInfo.ForeColor = System.Drawing.Color.FromArgb(90, 110, 140);
            this.lblInfo.Location = new System.Drawing.Point(30, 415);
            this.lblInfo.Size = new System.Drawing.Size(500, 20);

            // Botón grande (cargar)
            this.btnAccion.Text = "CARGAR IMAGEN";
            this.btnAccion.Size = new System.Drawing.Size(360, 40);
            this.btnAccion.Location = new System.Drawing.Point(100, 400);
            this.btnAccion.BackColor = System.Drawing.Color.FromArgb(45, 135, 255);
            this.btnAccion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccion.FlatAppearance.BorderSize = 0;
            this.btnAccion.ForeColor = System.Drawing.Color.White;
            this.btnAccion.Name = "btnAccion";

            // Botón Iniciar escaneo (aparece al cargar imagen)
            this.btnScan.Text = "Iniciar escaneo";
            this.btnScan.Size = new System.Drawing.Size(160, 34);
            this.btnScan.BackColor = System.Drawing.Color.FromArgb(45, 135, 255);
            this.btnScan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScan.FlatAppearance.BorderSize = 0;
            this.btnScan.ForeColor = System.Drawing.Color.White;
            this.btnScan.Name = "btnScan";
            this.btnScan.Visible = false;

            // Botón Cancelar (aparece al cargar imagen)
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.Size = new System.Drawing.Size(160, 34);
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(96, 109, 128);
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.ForeColor = System.Drawing.Color.White;
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Visible = false;

            // Agregar a card
            this.cardPanel.Controls.Add(this.picLogo);
            this.cardPanel.Controls.Add(this.lblCardTitulo);
            this.cardPanel.Controls.Add(this.lblCardSubtitulo);
            this.cardPanel.Controls.Add(this.picViewer);
            this.cardPanel.Controls.Add(this.lblInfo);
            this.cardPanel.Controls.Add(this.btnAccion);
            this.cardPanel.Controls.Add(this.btnScan);
            this.cardPanel.Controls.Add(this.btnCancelar);

            // Agregar al form
            this.mainArea.Controls.Add(this.cardPanel);
            this.Controls.Add(this.mainArea);
            this.Controls.Add(this.sidebar);

            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picViewer)).EndInit();
            this.ResumeLayout(false);
        }
    }
}