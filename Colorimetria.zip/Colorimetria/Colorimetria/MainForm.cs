﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Colorimetria
{
    public partial class MainForm : Form
    {
        // Márgenes de la CARD respecto al mainArea (ajústalos a gusto)
        private const int CardMarginLeft = 24;
        private const int CardMarginTop = 24;
        private const int CardMarginRight = 24;
        private const int CardMarginBottom = 24;

        // Mínimos por seguridad (si la ventana se hace muy pequeña)
        private const int CardMinWidth = 560;
        private const int CardMinHeight = 460;

        // Separaciones internas
        private const int MargenInferior = 18;    // margen interior inferior de la card para los botones
        private const int Separacion = 10;
        private const int SeparacionBotones = 12;
        private const int AltoMinVisor = 140;

        public MainForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // Eventos
            this.Resize += MainForm_Resize;

            // Cargar imagen
            this.btnAccion.Click += BtnAccion_Click;
            this.picViewer.Click += BtnAccion_Click;
            this.lblDropHint.Click += BtnAccion_Click;

            // Con imagen cargada
            this.btnScan.Click += BtnScan_Click;
            this.btnCancelar.Click += BtnCancelar_Click;

            // (Opcional) menús laterales
            this.btnNuevoAnalisis.Click += delegate { MessageBox.Show("Nuevo análisis"); };
            this.btnHistorial.Click += delegate { MessageBox.Show("Historial de lotes"); };
            this.btnTolerancias.Click += delegate { MessageBox.Show("Config. de tolerancias"); };
            this.btnBaseDatos.Click += delegate { MessageBox.Show("Base de datos"); };

            // Drag & Drop
            EnableDragAndDrop();

            // Estado inicial
            this.AcceptButton = this.btnAccion;
            UpdateDropHintVisibility();
            DoResponsiveLayout();
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            DoResponsiveLayout();
        }

        // =========================================================
        // ===============   L A Y O U T   D I N Á M I C O   =======
        // =========================================================
        private void DoResponsiveLayout()
        {
            if (this.mainArea == null || this.cardPanel == null) return;

            // 1) Hacer que la CARD ocupe todo el mainArea con los márgenes definidos
            int availW = Math.Max(0, this.mainArea.ClientSize.Width - (CardMarginLeft + CardMarginRight));
            int availH = Math.Max(0, this.mainArea.ClientSize.Height - (CardMarginTop + CardMarginBottom));

            int cardW = Math.Max(CardMinWidth, availW);
            int cardH = Math.Max(CardMinHeight, availH);

            // Si el mainArea es suficientemente grande, que la card llene hasta los márgenes
            // Si es más pequeño que el mínimo, la card mantendrá su mínimo y quedará centrada.
            int cardX = CardMarginLeft + (availW > cardW ? (availW - cardW) / 2 : 0);
            int cardY = CardMarginTop + (availH > cardH ? (availH - cardH) / 2 : 0);

            this.cardPanel.Size = new Size(cardW, cardH);
            this.cardPanel.Location = new Point(cardX, cardY);

            // 2) Posicionar título/subtítulo (y logo si lo usas)
            if (this.lblCardTitulo != null)
                this.lblCardTitulo.Location = new Point((this.cardPanel.Width - this.lblCardTitulo.Width) / 2, 150);

            if (this.lblCardSubtitulo != null)
                this.lblCardSubtitulo.Location = new Point(
                    (this.cardPanel.Width - this.lblCardSubtitulo.Width) / 2,
                    this.lblCardTitulo.Bottom + 8
                );

            // 3) Zona variable: visor + metadatos + botones
            int topVisor = Math.Max(this.lblCardSubtitulo.Bottom + 10, 190);
            int bottomCard = this.cardPanel.Height - MargenInferior;

            bool imagenCargada = (this.picViewer != null && this.picViewer.Image != null);

            int altoMetadatos = (this.lblInfo != null ? this.lblInfo.Height : 18);
            int altoBotones = imagenCargada ? Math.Max(this.btnScan.Height, this.btnCancelar.Height)
                                              : this.btnAccion.Height;

            // Altura máxima disponible para el visor
            int altoDispVisor = bottomCard - Separacion - (altoMetadatos + Separacion + altoBotones) - topVisor;
            if (altoDispVisor < AltoMinVisor) altoDispVisor = AltoMinVisor;

            // Ancho disponible para el visor (dejamos ~30px a cada lado)
            int margenLateral = 30;
            int anchoDisp = this.cardPanel.Width - (margenLateral * 2);

            // 4) Ajuste por relación de aspecto real de la imagen (para que se vea COMPLETA y lo más grande posible)
            int targetW = anchoDisp;
            int targetH = altoDispVisor;
            if (this.picViewer != null && this.picViewer.Image != null)
            {
                int imgW = this.picViewer.Image.Width;
                int imgH = this.picViewer.Image.Height;
                double scale = Math.Min((double)anchoDisp / Math.Max(1, imgW),
                                        (double)altoDispVisor / Math.Max(1, imgH));
                targetW = Math.Max(1, (int)Math.Round(imgW * scale));
                targetH = Math.Max(1, (int)Math.Round(imgH * scale));
            }

            if (this.picViewer != null)
            {
                this.picViewer.SizeMode = PictureBoxSizeMode.Zoom;
                this.picViewer.Size = new Size(targetW, targetH);
                this.picViewer.Location = new Point((this.cardPanel.Width - this.picViewer.Width) / 2, topVisor);
            }

            // 5) Metadatos bajo el visor
            if (this.lblInfo != null)
            {
                this.lblInfo.Location = new Point(margenLateral, this.picViewer.Bottom + 6);
                this.lblInfo.Width = this.cardPanel.Width - (margenLateral * 2);
            }

            // 6) Botones (y traer al frente)
            if (imagenCargada)
            {
                this.btnAccion.Visible = false;
                this.btnScan.Visible = true;
                this.btnCancelar.Visible = true;
                this.AcceptButton = this.btnScan;

                int total = this.btnScan.Width + SeparacionBotones + this.btnCancelar.Width;
                int xInicio = (this.cardPanel.Width - total) / 2;
                int yBotones = this.cardPanel.Height - MargenInferior - this.btnScan.Height;

                this.btnScan.Location = new Point(xInicio, yBotones);
                this.btnCancelar.Location = new Point(this.btnScan.Right + SeparacionBotones, yBotones);

                // Z-order al frente
                this.btnScan.BringToFront();
                this.btnCancelar.BringToFront();
                this.cardPanel.Controls.SetChildIndex(this.btnScan, 0);
                this.cardPanel.Controls.SetChildIndex(this.btnCancelar, 0);
            }
            else
            {
                this.btnAccion.Visible = true;
                this.btnScan.Visible = false;
                this.btnCancelar.Visible = false;
                this.AcceptButton = this.btnAccion;

                this.btnAccion.Location = new Point(
                    (this.cardPanel.Width - this.btnAccion.Width) / 2,
                    this.cardPanel.Height - MargenInferior - this.btnAccion.Height
                );

                // Z-order del botón grande
                this.btnAccion.BringToFront();
                this.cardPanel.Controls.SetChildIndex(this.btnAccion, 0);
            }
        }

        private void UpdateDropHintVisibility()
        {
            if (this.lblDropHint == null || this.picViewer == null) return;
            this.lblDropHint.Visible = (this.picViewer.Image == null);
        }

        // ==============================
        //   C A R G A R   I M A G E N
        // ==============================
        private void BtnAccion_Click(object sender, EventArgs e)
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Title = "Selecciona una imagen";
                dlg.Filter = "Imágenes|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|Todos los archivos|*.*";
                dlg.Multiselect = false;

                if (dlg.ShowDialog(this) == DialogResult.OK)
                    LoadImageSafe(dlg.FileName);
            }
        }

        private void LoadImageSafe(string path)
        {
            try
            {
                if (this.picViewer.Image != null)
                {
                    Image old = this.picViewer.Image;
                    this.picViewer.Image = null;
                    old.Dispose();
                }

                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (var temp = Image.FromStream(fs))
                {
                    Bitmap clone = new Bitmap(temp);
                    this.picViewer.Image = clone;

                    FileInfo fi = new FileInfo(path);
                    string sizeText = fi.Length < 1024 * 1024
                        ? (fi.Length / 1024.0).ToString("0.#") + " KB"
                        : (fi.Length / (1024.0 * 1024.0)).ToString("0.##") + " MB";

                    this.lblInfo.Text = Path.GetFileName(path) + "  |  " +
                                        clone.Width + "×" + clone.Height + " px  |  " +
                                        sizeText;
                }

                UpdateDropHintVisibility();

                // Mostrar botones y asegurar z-order
                this.btnAccion.Visible = false;
                this.btnScan.Visible = true;
                this.btnCancelar.Visible = true;
                this.AcceptButton = this.btnScan;
                this.btnScan.BringToFront();
                this.btnCancelar.BringToFront();
                this.cardPanel.Controls.SetChildIndex(this.btnScan, 0);
                this.cardPanel.Controls.SetChildIndex(this.btnCancelar, 0);

                DoResponsiveLayout();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo cargar la imagen.\n\n" + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                this.lblInfo.Text = "Sin imagen cargada";
                if (this.picViewer != null) this.picViewer.Image = null;

                UpdateDropHintVisibility();

                // Volver a inicio
                this.btnAccion.Visible = true;
                this.btnScan.Visible = false;
                this.btnCancelar.Visible = false;
                this.AcceptButton = this.btnAccion;
                this.btnAccion.BringToFront();
                this.cardPanel.Controls.SetChildIndex(this.btnAccion, 0);

                DoResponsiveLayout();
            }
        }

        // ==============================
        //   A C C I Ó N   E S C A N E O
        // ==============================
        private void BtnScan_Click(object sender, EventArgs e)
        {
            // TODO: integra tu flujo real (TWAIN/WIA/SDK)
            MessageBox.Show("Escaneo iniciado… (demo)", "Escaneo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // ==============================
        //   C A N C E L A R / R E S E T
        // ==============================
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            if (this.picViewer.Image != null)
            {
                Image old = this.picViewer.Image;
                this.picViewer.Image = null;
                old.Dispose();
            }
            this.lblInfo.Text = "Sin imagen cargada";

            UpdateDropHintVisibility();

            // Volver a inicio
            this.btnAccion.Visible = true;
            this.btnScan.Visible = false;
            this.btnCancelar.Visible = false;
            this.AcceptButton = this.btnAccion;
            this.btnAccion.BringToFront();
            this.cardPanel.Controls.SetChildIndex(this.btnAccion, 0);

            DoResponsiveLayout();
        }

        // ==============================
        //   D R A G  &  D R O P
        // ==============================
        private void EnableDragAndDrop()
        {
            if (this.cardPanel == null) return;

            this.cardPanel.AllowDrop = true;

            this.cardPanel.DragEnter += delegate (object sender, DragEventArgs e)
            {
                IDataObject data = e.Data as IDataObject;
                if (data != null && data.GetDataPresent(DataFormats.FileDrop))
                {
                    e.Effect = DragDropEffects.Copy;
                    if (this.lblDropHint != null) this.lblDropHint.ForeColor = Color.FromArgb(30, 120, 200);
                }
                else
                {
                    e.Effect = DragDropEffects.None;
                }
            };

            this.cardPanel.DragLeave += delegate (object sender, EventArgs e)
            {
                if (this.lblDropHint != null) this.lblDropHint.ForeColor = Color.FromArgb(120, 120, 120);
            };

            this.cardPanel.DragDrop += delegate (object sender, DragEventArgs e)
            {
                try
                {
                    if (this.lblDropHint != null) this.lblDropHint.ForeColor = Color.FromArgb(120, 120, 120);

                    IDataObject data = e.Data as IDataObject;
                    if (data != null && data.GetDataPresent(DataFormats.FileDrop))
                    {
                        string[] files = data.GetData(DataFormats.FileDrop) as string[];
                        if (files != null && files.Length > 0)
                            LoadImageSafe(files[0]);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo cargar la imagen.\n\n" + ex.Message,
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
        }
    }
}