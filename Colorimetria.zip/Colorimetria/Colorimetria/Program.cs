﻿using System;
using System.Windows.Forms;

namespace Colorimetria
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // WinForms para .NET Framework 4.7.2
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new MainForm());
        }
    }
}